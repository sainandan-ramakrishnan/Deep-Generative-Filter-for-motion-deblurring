cd models
curl -O "http://cs.stanford.edu/people/jcjohns/fast-neural-style/models/vgg16.t7"
cd ../
